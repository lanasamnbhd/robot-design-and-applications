# Solving-CarRacing-with-DDPG

Using DDPG and TD3 to solve CarRacing-V0 from OpenAI gym.

To run: <br>
- if on local machine: python3 car_racing.py [choose policy: DDPG or TD3]
- if from headless remote server: using ssh, xvfb-run -a -s "-screen 0 1400x900x24 +extension RANDR" -- python3 car_racing.py [choose policy: DDPG or TD3]

